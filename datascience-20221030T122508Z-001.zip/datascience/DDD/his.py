import requests
 
def helloworld():
    return(helloworld)
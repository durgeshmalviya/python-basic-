
from instabot import Bot


bot = Bot()

bot.login(username="dsmalviya@yahoo.in",
password="The Hobbit@2")

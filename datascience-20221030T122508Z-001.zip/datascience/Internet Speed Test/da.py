from ast import Num


def myfnc():
    num = (1,20,2,6,562,666,)
           
    print(myfnc)
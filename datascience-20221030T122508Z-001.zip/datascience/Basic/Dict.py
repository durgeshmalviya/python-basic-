# dict. operations

Dictlog={"rollno":["01,02,03,04,05"],
"name":["ram","om","kumar","abid","abdul"],
"subject":["Bcom,BE, Mca,Msc,Mcom "],
"Marks":[87,96,89,91,90],
"Marks":[92,99,88,71,97],}
y= Dictlog.keys()
x= Dictlog.values()


Dictlog={"ID":["ID01","D02"]}
print{}



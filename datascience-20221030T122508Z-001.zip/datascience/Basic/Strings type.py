x=8
y=9
z=1
a= []

a.append[x]
a.append[y]
a.append[z]

a.sort()
print(a)
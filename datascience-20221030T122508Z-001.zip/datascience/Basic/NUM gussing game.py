import random
X=random.randint(1,100)
Y=input (77)

print (Y)
X = ("Name",["Aman" ,"Happy","JAi","Omega"]),
("Roll No",[10,15,16,45])
Y = input("Roll No")
print(type(Y))
print(Y)
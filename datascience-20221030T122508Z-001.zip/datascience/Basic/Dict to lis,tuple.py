from webbrowser import get


Mydict = {"MBA":["IT","HR","HA","HM"],
"Students":["20","25","15","10"]}
print(get("IT"))
print(Mydict)

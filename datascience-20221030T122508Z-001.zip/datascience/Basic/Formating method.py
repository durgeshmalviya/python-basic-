age = (input())
z="my age is {}"
print(z.format(age))
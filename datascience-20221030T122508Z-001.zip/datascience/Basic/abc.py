#def myfnc( ): x =50def abc ( ):x = 20print(x) Do not allows duplicates


from webbrowser import get


Dictlog={"rollno":"01,02,03,04,05"}
print(Dictlog.keys())
print(Dictlog.values())

    


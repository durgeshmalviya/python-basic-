myver1 = 20
print(myver1)
n=6
for i in range(n):
    for j in range(i+1):
        print(10-j*2,end=" ")
    print()
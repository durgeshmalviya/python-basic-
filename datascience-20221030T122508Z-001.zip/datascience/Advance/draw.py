from sketchpy import library as lib 
obj = lib.()
obj.draw()
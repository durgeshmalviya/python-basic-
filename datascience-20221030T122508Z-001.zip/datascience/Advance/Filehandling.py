f=open("C:\\Users\durge\Desktop\DS2.txt",'w')
x="hEllo Drex MIopP"
f.write(x)

f=open("C:\\Users\durge\Desktop\DS2.txt",'r')
print(f.read())


# 'r' = read file but via print( method)
# 'w' =   update file data write or someting on the file 
# 'x' = create file or folder 
# 't' 


